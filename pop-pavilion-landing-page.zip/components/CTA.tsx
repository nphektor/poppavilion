
import React from 'react';

const CTA: React.FC = () => {
  return (
    <section className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400">
      <div className="container mx-auto px-6 py-16 md:py-20 text-center">
        <h3 className="text-4xl md:text-5xl font-bold font-fredoka text-white">Ready for an Adventure?</h3>
        <p className="mt-4 text-sky-100 max-w-2xl mx-auto text-lg">
          The Pavilion is open! Come on in, look around, and find your next favorite collectible!
        </p>
        <div className="mt-8">
          <a
            href="#store"
            className="inline-block bg-white text-blue-600 font-bold text-lg px-10 py-4 rounded-full hover:bg-gray-100 transition-transform transform hover:scale-110 shadow-2xl"
          >
            Explore The Store!
          </a>
        </div>
      </div>
    </section>
  );
};

export default CTA;
