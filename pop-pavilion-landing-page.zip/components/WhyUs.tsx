
import React from 'react';
import { BoxIcon, ShieldCheckIcon, TruckIcon, StarIcon } from './Icons';

const features = [
  {
    Icon: BoxIcon,
    title: 'Huge Collection',
    description: 'We have tons of toys, from brand new stuff to super rare finds!',
    color: 'from-yellow-200 to-orange-200',
    iconColor: 'text-orange-500',
  },
  {
    Icon: ShieldCheckIcon,
    title: 'Perfect Condition',
    description: 'We treat every toy like a treasure so it gets to you looking amazing.',
    color: 'from-sky-200 to-cyan-200',
    iconColor: 'text-cyan-500',
  },
  {
    Icon: TruckIcon,
    title: 'Super-Fast Shipping',
    description: 'Vroom! Your new collectibles will be on their way to you in a flash.',
    color: 'from-lime-200 to-green-200',
    iconColor: 'text-green-500',
  },
  {
    Icon: StarIcon,
    title: 'Made by Fans',
    description: 'We love collecting just as much as you do, so we know what\'s cool!',
    color: 'from-violet-200 to-fuchsia-200',
    iconColor: 'text-fuchsia-500',
  },
];

const WhyUs: React.FC = () => {
  return (
    <section className="bg-white py-16 md:py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h3 className="text-4xl md:text-5xl font-bold font-fredoka text-gray-900">Why We're Awesome</h3>
          <p className="mt-2 text-gray-600 text-lg">Here's what makes Pop Pavilion the best place for fun!</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {features.map((feature, index) => (
            <div key={index} className="text-center p-6 bg-gray-50 rounded-2xl transform transition-transform hover:scale-105 hover:-rotate-2">
              <div className={`flex items-center justify-center h-20 w-20 mx-auto rounded-full bg-gradient-to-br ${feature.color} mb-4`}>
                <feature.Icon className={`h-10 w-10 ${feature.iconColor}`} />
              </div>
              <h4 className="text-2xl font-bold font-fredoka text-gray-900 mb-2">{feature.title}</h4>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyUs;
