
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200">
      <div className="container mx-auto px-6 py-6 text-center text-gray-600">
        <p>&copy; {new Date().getFullYear()} Pop Pavilion. All Rights Reserved.</p>
        <div className="mt-4 flex justify-center space-x-6">
          <a href="#" className="hover:text-purple-600 transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-purple-600 transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-purple-600 transition-colors">Contact Us</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
